import React from 'react'
import AboutImg from '../assets/images/abouut.png';
const About = () => {
  return (
    <div className='about'>
        <div className='container'>
            <div className='row'>
            <div className='col-md-6'>
                <div className='about-image'>
                    <img src={AboutImg} alt="about" />
                </div>
            </div>
            <div className='col-md-6'>
                <div className='about-content'>
                    <h3>We Help You to Find Best Properties</h3>
                    <p>TopHaven is a full stack service provider for all real estate needs, with 15+ services including home loans, pay rent, packers and movers, legal assistance, property valuation, and expert advice.</p>
                </div>
            </div>
            </div>
        </div>
    </div>
  )
}

export default About