import React from 'react'

const Homebanner = () => {
  return (
    <div className='FrontBanner' >
        <div className='banner-overlay'></div>
        <div className='container'>
            <div className='row'>
                <div className='HeadingBanner'>
                    <h2>We Helping to you find the property of your dreams</h2>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Homebanner