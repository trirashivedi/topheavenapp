import React from 'react'
import Card from 'react-bootstrap/Card';
import ListGroup from 'react-bootstrap/ListGroup';
import { FaHeart  } from "react-icons/fa";


const Property = (props) => {
    const {propertyDetails}= props
  return (
    <div className='property'>
        <div className='propertyInnerContent'>
          <Card >
          <Card.Img variant="top" src={propertyDetails.image} />
          <Card.Body>
            <Card.Title>{ propertyDetails.priceRange}</Card.Title>
            <Card.Text>{propertyDetails.title}<br />
            <p>{propertyDetails.owner}</p>
            </Card.Text>
          </Card.Body>
          <ListGroup className="list-group-flush">
            <ListGroup.Item>
             <ul>
                <li>{propertyDetails.bedroom} Bedroom</li>
                <li>{propertyDetails.bathroom} Bathroom</li>
                <li> <FaHeart/>{propertyDetails.area} M</li>
             </ul>
            </ListGroup.Item>
          </ListGroup>
        </Card>
        </div>
    </div>
    
      
      );
    }
    

export default Property