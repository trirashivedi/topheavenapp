import React from 'react'
import Navbar from './components/Navbar';


const Detailedpage = () => {
  return (
    <div className='Detailedpage'>
       <Navbar/>
    </div>
  )
}

export default Detailedpage