
import './assets/css/style.css';
import About from './components/About';
import Blog from './components/Blog';
import Contact from './components/Contact';
import FilteredResults from './components/FilteredResults';
import FilterSection from './components/FilterSection';
import Footer from './components/Footer';
import Homebanner from './components/Homebanner';
import Navbar from './components/Navbar';
import OtherProperties from './components/OtherProperties';
import {BrowserRouter as Router, Routes, Route} from "react-router-dom";
function App() {
  return (
<>
  <Navbar />
   <Homebanner />
   <FilterSection />
   <FilteredResults />
   <About />
   <OtherProperties />
   <Blog />
   <Contact />
   <Footer />
  {/* <Router>
     <Routes>
            <Route path = "/" element = { < Home /> } />
            <Route path = "/about" element = { < About /> } />
            <Route path = "/products" element = { < Products /> } />
            <Route path = "/contact" element = { < Contact /> } />
            <Route path = "/detailedpage/:id" element = { < Detailedpage /> } />
     </Routes>
  </Router> */}

</>
 
   
  );
}

export default App;
